import os
import sys
import time

from tkinter import *
import cv2
from pprint import pprint
import numpy as np
import tkinter as tk
from PIL import ImageTk, Image

import tkinter as tk
from tkinter import *
import time
import PIL
from PIL import Image, ImageTk, ImageSequence
class intro:
    def __init__(self):
        root = Tk()

        root.geometry("800x450")
        root.minsize(800,450)
        root.maxsize(800,450)



        title = tk.Label(text="IMAGE RECONSTRUCTOR", fg="#096A56",  bg="#DEBCF4", font="AbrilFatface 25 bold")
        title.pack(fill=X)


        bg_img=PhotoImage(file="back.png")
        lab=Label(root,image=bg_img)
        lab.pack(side=TOP,fill=Y)

        global giff
        giff = PhotoImage(file="2.png")

        label = tk.Label(lab, bg="black", image=giff)
        label.place(width=200, height=200, relx=0.1, rely=0.20)


        def button1_callback():
            print("Button 1 clicked!")

        def button2_callback():
            print("Button 2 clicked!")
            root.destroy()
            ImageSearch()
        def button3_callback():
            print("Button 3 clicked!")
            root.destroy()
            ImageSearch2()


        button1 = tk.Button(root, text="Close", command=button1_callback, bg="#D9D9D9", fg="#096A56", font=("Arial", 16))
        button1.pack(side=LEFT, padx=30, pady=50)
        button1.place(x=50, y=350)


        button2 = tk.Button(root, text="Single", command=button2_callback, bg="#FAE73A", fg="#096A56", font=("Arial", 16))
        button2.pack(side=LEFT, padx=30, pady=50)
        button2.place(x=160, y=350)

        button3 = tk.Button(root, text="Combine", command=button3_callback, bg="#FAE73A", fg="#096A56", font=("Arial", 16))
        button3.pack(side=LEFT, padx=30, pady=50)
        button3.place(x=270, y=350)

        root.mainloop()

class ImageSearch:
    def __init__(self):
        root = Tk()
        root.geometry("800x450")
        root.minsize(800,450)
        root.maxsize(800,450)
        root.title("Image Generator")

        title = tk.Label(text="Generate an Image Using Genetic Algorithm", fg="#096A56",  bg="#DEBCF4", font="AbrilFatface 25 bold")
        title.pack(fill=X)

        bg = PhotoImage(file="lbg.png")
        photo = PhotoImage(file="1.png")

        left_frame = tk.Frame(root, height=415, width=400)
        left_bg = tk.Label(left_frame, image=bg, width=400)
        left_bg.pack(side=RIGHT, fill=Y)
        left_frame.pack(side=LEFT, fill=Y)

        bgimg = PhotoImage(file="greybg.png")

        label = Label(left_bg, text="Search an Image", fg="#096A56", bg="grey", font=("comicsansms", 20, "bold"))
        label.pack(pady=50,padx=90)

        text = tk.Entry(left_bg, width=40, bg="white")
        text.pack(padx=20)

        text.insert(0, "Search")
        text.configure(state=DISABLED)
        def on_click(event):
            text.configure(state=NORMAL)
            text.delete(0, END)

        def clear():
            text.delete(0, END)

        def s(x):

            myInput = text.get()

            from GeneticUtility import GeneticUtility
            from Config import Config

            # Define fitness function
            def fitnessFunction(chromosome):
                fitness = 0
                for i in range(0, len(imageFlattened)):
                    fitness += pow((imageFlattened[i] - chromosome.genes[i]), 2)

                return fitness

            # Read example image
            myInput = myInput.lower()
            im = ''
            if (myInput.find("smiley") != -1 or myInput.find("smile") != -1):
                image = cv2.imread('smiley.png', 0)
                im = 'smiley.png'
            elif (myInput.find("sad") != -1):
                image = cv2.imread('sad.png', 0)
                im = 'sad.png'

            elif (myInput.find("snake") != -1):
                image = cv2.imread('s.jpg', 0)
                im = 's.jpg'
            elif (myInput.find("w sign") != -1):
                image = cv2.imread('w.png', 0)
                im = 'w.png'
            elif (myInput.find("circle") != -1 or myInput.find("round") != -1):
                image = cv2.imread('circle.jpg', 0)
                im = 'circle.jpg'
            elif (myInput.find("star") != -1 or myInput.find("sitara") != -1):
                image = cv2.imread('star.png', 0)
                im = 'star.png'
            elif (myInput.find("cross") != -1 or myInput.find("plus") != -1):
                image = cv2.imread('cross.jpg', 0)
                im = 'cross.jpg'
            elif (myInput.find("a sign") != -1):
                image = cv2.imread('a.png', 0)
                im = 'a.jpg'
            # Convert Image to List
            imageFlattened = image.flatten().tolist()
            img = Image.open(im)
            resized_image = img.resize((200, 200), Image.ANTIALIAS)
            new_image = ImageTk.PhotoImage(resized_image)
            label = Label(right_frame, image=new_image)
            label.pack()


            root.update()
            # Convert 255's to 1 and rest to 0
            # This is done in order to create binary image
            print(imageFlattened)
            for i in range(0, len(imageFlattened)):
                if imageFlattened[i] == 255:
                    imageFlattened[i] = 1
                else:
                    imageFlattened[i] = 0

            image = np.reshape(imageFlattened, (20, 20)) * 255.0

            # Step Executor Function
            # Called after Each Generation for Any Action That the Programmer might want to execute
            # Here we use this method to show the formed image at each step
            def stepExecutor(generationNumber, bestIndividual):
                bestIndividual = np.array(bestIndividual.genes)
                bestIndividual = bestIndividual * 255.0
                bestIndividual = np.reshape(bestIndividual, (20, 20))
                bestIndividual = cv2.resize(bestIndividual, (200, 200))

                # Show original Image and Formed Image at each step

                # cv2.imshow("original Image", cv2.resize(image, (200, 200)))
                # label = Label(frame, image= img)
                label.pack()
                root.update()
                cv2.imshow("formed image", bestIndividual)
                path = 'C:/Users/FAHAD_ISHAQ/OneDrive - Higher Education Commission/Desktop/Final Project/Genetic-Algorithm-In-Python-master/Image-Reconstructer'
                cv2.imwrite(os.path.join(path, 'img.png'), bestIndividual)
                img2 = Image.open("img.png")
                resized_image2 = img2.resize((200, 200), Image.ANTIALIAS)
                new_image2 = ImageTk.PhotoImage(resized_image2)

                #reconstructed img png
                label2 = Label(right_frame, image=new_image2)
                label2.place(relwidth=0, relheight=50)
                label2.pack()

                root.update()

                label2.destroy()
                time.sleep(0.2)
                root.update()

                # cv2.imwrite('img.png', bestIndividual)
                key = cv2.waitKey(1)

            util = GeneticUtility()
            x = util.simulateEvolution(300, fitnessFunction, stepExecution=stepExecutor)
            x = np.array(x.genes)
            x = x * 255.0
            x = np.reshape(x, (20, 20))

            img2 = Image.open("img.png")
            resized_image2 = img2.resize((200, 200), Image.ANTIALIAS)
            new_image2 = ImageTk.PhotoImage(resized_image2)
            label2 = Label(right_frame, image=new_image2)

            label2.pack()
            root.update()
            cv2.imshow("formed image", x)

            cv2.waitKey(0)
            print(x)

        text.bind("<Button-1>",on_click)
        clear = tk.Button(left_bg, text="Clear", fg="#096A56",  bg="lightgrey", font="comicsansms 15 bold", command=clear, width=5)
        clear.pack(pady=80, side=LEFT, padx=80)
        button_frame = tk.Frame(left_bg, bg="red")
        img = PhotoImage(file="1.png")
        bg_img = tk.Label(button_frame, image=img, bg="#F2F2F2")
        bg_img.pack()
        search = tk.Label(bg_img, text="Search", fg="#096A56",  bg="#FAE73A", font="comicsansms 15 bold")
        search.pack(pady=80, side=RIGHT, padx=30)
        search.bind("<Button>", s)
        button_frame.pack(pady=20)
        right_frame = tk.Frame(root, bg="white", height=415, width=400)
        right_frame.pack(side=TOP)


        root.mainloop()

class ImageSearch2:
    def __init__(self):
        root = Tk()
        root.geometry("800x450")
        root.minsize(800,450)
        root.maxsize(800,450)
        root.title("Image Generator")

        title = tk.Label(text="Generate an Image Using Genetic Algorithm", fg="#096A56",  bg="#DEBCF4", font="AbrilFatface 25 bold")
        title.pack(fill=X)

        bg = PhotoImage(file="lbg.png")
        photo = PhotoImage(file="1.png")

        left_frame = tk.Frame(root, height=415, width=400)
        left_bg = tk.Label(left_frame, image=bg, width=400)
        left_bg.pack(side=RIGHT, fill=Y)
        left_frame.pack(side=LEFT, fill=Y)

        bgimg = PhotoImage(file="greybg.png")

        label = Label(left_bg, text="Search an Image", fg="#096A56", bg="grey", font=("comicsansms", 20, "bold"))
        label.pack(pady=50,padx=90)

        text = tk.Entry(left_bg, width=40, bg="lightgrey")
        text.pack(padx=20)

        text.insert(0, "Search")
        text.configure(state=DISABLED)
        def on_click(event):
            text.configure(state=NORMAL)
            text.delete(0, END)

        def clear():
            text.delete(0, END)

        def s(x):
            print(x)

            myInput = text.get()
            from GeneticUtility import GeneticUtility
            from Config import Config

            # Define fitness function
            def fitnessFunction(chromosome):
                fitness = 0
                for i in range(0, len(imageFlattened)):
                    fitness += pow((imageFlattened[i] - chromosome.genes[i]), 2)

                return fitness

            # Read example image
            myInput = myInput.lower()
            if (myInput.find("two") != -1 or myInput.find("2")!=-1 and myInput.find("lines") != -1 and myInput.find("cross")!=-1):
                image = cv2.imread('line1.png', 0)
                im = "line1.png"
                image2 = cv2.imread('line2.png', 0)
                im2 = "line2.png"
            elif (myInput.find("square") != -1 and myInput.find("circle")!=-1):
                image = cv2.imread('r1.png', 0)
                im = "r1.png"
                image2 = cv2.imread('c1.png', 0)
                im2 = "c1.png"

            elif (myInput.find("squares") != -1 or myInput.find("square") != -1 or
                  myInput.find("2") != -1 or myInput.find("two") != -1 and
                  myInput.find("cube") != -1):
                image = cv2.imread('sq1.png', 0)
                im = "sq1.png"
                image2 = cv2.imread('sq2.png', 0)
                im2 = "sq2.png"

            # Convert Image to List
            img = Image.open(im)
            resized_image = img.resize((100, 90), Image.ANTIALIAS)
            new_image = ImageTk.PhotoImage(resized_image)
            label = Label(right_frame, image=new_image)
            label.pack()
            img2 = Image.open(im2)
            resized_image2 = img2.resize((100, 90), Image.ANTIALIAS)
            new_image2 = ImageTk.PhotoImage(resized_image2)
            label1 = Label(right_frame, image=new_image2)
            label1.pack(pady=10)
            imageFlattened = image.flatten().tolist()
            imageFlattened2 = image2.flatten().tolist()

            for i in range(len(imageFlattened2)):
                if (imageFlattened2[i] == 0):
                    imageFlattened[i] = 0
            root.update()
            # Convert 255's to 1 and rest to 0
            # This is done in order to create binary image
            print(imageFlattened)
            for i in range(0, len(imageFlattened)):
                if imageFlattened[i] == 255:
                    imageFlattened[i] = 1
                else:
                    imageFlattened[i] = 0

            image = np.reshape(imageFlattened, (20, 20)) * 255.0

            # Step Executor Function
            # Called after Each Generation for Any Action That the Programmer might want to execute
            # Here we use this method to show the formed image at each step
            def stepExecutor(generationNumber, bestIndividual):
                bestIndividual = np.array(bestIndividual.genes)
                bestIndividual = bestIndividual * 255.0
                bestIndividual = np.reshape(bestIndividual, (20, 20))
                bestIndividual = cv2.resize(bestIndividual, (200, 200))

                # Show original Image and Formed Image at each step

                # cv2.imshow("original Image", cv2.resize(image, (200, 200)))
                # label = Label(frame, image= img)
                label.pack()
                root.update()
                cv2.imshow("formed image", bestIndividual)
                path = 'C:/Users/FAHAD_ISHAQ/OneDrive - Higher Education Commission/Desktop/Final Project/Genetic-Algorithm-In-Python-master/Image-Reconstructer'
                cv2.imwrite(os.path.join(path, 'img.png'), bestIndividual)
                img2 = Image.open("img.png")
                resized_image2 = img2.resize((200, 200), Image.ANTIALIAS)
                new_image2 = ImageTk.PhotoImage(resized_image2)
                label2 = Label(right_frame, image=new_image2)
                label2.pack()

                root.update()

                label2.destroy()
                time.sleep(0.2)
                root.update()

                # cv2.imwrite('img.png', bestIndividual)
                key = cv2.waitKey(1)

            util = GeneticUtility()
            x = util.simulateEvolution(300, fitnessFunction, stepExecution=stepExecutor)
            x = np.array(x.genes)
            x = x * 255.0
            x = np.reshape(x, (20, 20))

            img2 = Image.open("img.png")
            resized_image2 = img2.resize((200, 200), Image.ANTIALIAS)
            new_image2 = ImageTk.PhotoImage(resized_image2)
            label2 = Label(right_frame, image=new_image2)
            label2.pack(side=BOTTOM, anchor="s")
            root.update()
            cv2.imshow("formed image", x)

            cv2.waitKey(0)

        text.bind("<Button-1>",on_click)
        clear = tk.Button(left_bg, text="Clear", fg="#096A56",  bg="lightgrey", font="comicsansms 15 bold", command=clear, width=5)
        clear.pack(pady=80, side=LEFT, padx=80)
        button_frame = tk.Frame(left_bg, bg="red")
        img = PhotoImage(file="1.png")
        bg_img = tk.Label(button_frame, image=img, bg="#F2F2F2")
        bg_img.pack()
        search = tk.Label(bg_img, text="Search", fg="#096A56",  bg="#FAE73A", font="comicsansms 15 bold")
        search.pack(pady=80, side=RIGHT, padx=30)
        search.bind("<Button>", s)
        button_frame.pack(pady=20)
        right_frame = tk.Frame(root, bg="white", height=415, width=400)
        right_frame.pack(side=TOP)


        root.mainloop()

intro()