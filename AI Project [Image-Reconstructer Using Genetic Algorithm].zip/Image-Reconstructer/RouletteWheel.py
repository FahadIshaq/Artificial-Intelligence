from Chromosome import Chromosome
from Config import Config

import random

class RouletteWheel(object):# Path: RouletteWheel.py
    
    def __init__(self, chromosomes, config):
        self.chromosomes = chromosomes
        self.config = config
        self.__createCumulativeProbabilities__()
    
    def RouletteWheelSelection(self):
        # Select first chromosome
        random1 = random.uniform(0, 1)
        chromosome1 = None
        for chromosome in self.chromosomes:
            if random1 <= chromosome.endRange:
                chromosome1 = Chromosome(self.config)
                chromosome1.genes = chromosome.genes
                break
        
        # Select second chromosome
        chromosome2 = None
        while True:
            random2 = random.uniform(0, 1)
            for chromosome in self.chromosomes:
                if random2 <= chromosome.endRange: #if the random number is less than the end range of the chromosome, then it is selected
                    chromosome2 = Chromosome(self.config) #create a new chromosome and copy the genes of the selected chromosome to it
                    chromosome2.genes = chromosome.genes #copy the genes of the selected chromosome to the new chromosome
                    
                    if chromosome1.genes != chromosome2.genes: #if the two chromosomes are not the same, then break the loop
                        return chromosome1, chromosome2 #return the two chromosomes

    def __createCumulativeProbabilities__(self): #create the cumulative probabilities
        self.__calculateCumulativeSum__() #calculate the cumulative sum
        self.__getNomalizedFitness__() #calculate the normalized fitness
        currentSum = 0
        for chromosome in self.chromosomes: #for each chromosome
            currentSum += chromosome.normalizedFitness #add the normalized fitness to the current sum
            chromosome.endRange = currentSum #the end range of the chromosome is the current sum
    
    def __calculateCumulativeSum__(self): #calculate the cumulative sum
        cumSum = 0
        for chromosome in self.chromosomes: #for each chromosome
            cumSum += chromosome.fitness #add the fitness of the chromosome to the cumulative sum
        self.cumSum = cumSum #the cumulative sum is the sum of the fitness of all the chromosomes
    
    def __getNomalizedFitness__(self):  #calculate the normalized fitness
        for chromosome in self.chromosomes:
            chromosome.normalizedFitness = chromosome.fitness / self.cumSum #it is the probability of each chromosome
